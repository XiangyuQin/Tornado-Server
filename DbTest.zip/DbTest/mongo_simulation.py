import pymongo
from pymongo import MongoClient

class TestMongo(object):
    def __init__(self):
        conn = MongoClient("localhost", 27017)
        self.db = conn["webSite"]

    def getDataId(self, type):
        cursor = self.db.articles
        cursor_doc = cursor.find({"type_id":type}).sort([("id", pymongo.DESCENDING)]).limit(1)
        if cursor_doc:
		    id = cursor_doc["id"]
            return str(id)
        else:
            return 0

    def insertArticle(self):
        id=self.getDataId()
        title=self.getRandomList(config.title)
        image=self.getRandomList(config.image)
        date=self.getRandomDate()
        brief=self.getRandomList(config.brief)
        type_id=self.getRandomList(config.type_id)
        writer=self.getRandomList(config.writer)
        content=self.getRandomList(config.content)
        rankingScore=self.getRandomFloat(start,end)
        article={"id":id,"title":title,"image":image,"date":date,"brief":brief,"type_id":type_id,"writer":writer,"content":content,"rankingScore":rankingScore}
        return 	article

    def getRandomFloat(self):
        return random.uniform(0,1)

    def getRandomDate(self):
        year=random.randint(2015, 2016)
        month=random.randint(0, 11)
        date=random.randint(0, 27)
        month=random.randint(0, 11)
        min=random.randint(0, 59)
        hour=random.randint(0, 23)
        second=random.randint(0, 59)
        return datetime.datetime(year, month, date, min, hour, second)

    def getRandomList(self, list):
        return random.choice(list)
        
if __name__=="__main__":
    test = TestMongo()
    abc = test.insertArticle()
    print abc