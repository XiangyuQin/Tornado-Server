# -*- coding:utf-8 -*-
import sys

def str2Int(strElement):
    try:
        intElement=int(strElement)
    except:
        intElement=0
    return intElement