# -*- coding:utf-8 -*-
import tornado.web
import config
from MongoService import MongoService

class MainHandler(tornado.web.RequestHandler):
    def get(self):
        mongoService=MongoService()
        themes_array=mongoService.getThemes(config.mainThemes)
        pptThemes_array=mongoService.getThemes(config.pptThemes)
        listArticles_array=getArticles(themes_array, config.MainArticlesNumber)
        pptArticles_array=getPptArticles(pptThemes_array, config.PptArticlesNumber)
        pptArticles_array=mergeArticleAndThemes(pptThemes_array, pptArticles_array)
        '''
        self.write(str(len(listArticles_array)))
        '''
        self.render(
            "index.html",
            page_title = config.WebTitle,
            urls=config.urls,
            themes=themes_array,
            listArticles=listArticles_array,
            pptArticles=pptArticles_array
        )

    def mergeArticleAndThemes(self, themes_array, pptArticles_array):
        array=[]
        for pptArticle in pptArticles_array:
            for theme in themes_array:
                if(theme["theme_id"]==themes_array["type_id"]):
                    pptArticle["theme"]=theme["title"]
                    break
        return pptArticles_array

    def getArticles(self, themes_array, limits):
        array=[]
        for theme in themes_array:
            listArticles=mongoService.getMainArticles(theme["theme_id"], config.MainArticlesNumber)
            array.extend(listArticles)
        return array