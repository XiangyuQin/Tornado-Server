# -*- coding:utf-8 -*-

themesType = {"0":"精品文章1","1":"精品文章2"}
urls = {"list_url":"http://115.159.116.153:8000/list", "article_url":"http://115.159.116.153:8000/article", "index_url":"http://115.159.116.153:8000"}
pageSize = 7
pageLimit = 9
times = 216

