# -*- coding:utf-8 -*-

themesType=
    {
        "0":"精品文章1",
        "1":"精品文章2",
    }

pageSize = 8
pageLimit = 5