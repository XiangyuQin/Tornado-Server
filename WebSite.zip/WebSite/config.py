# -*- coding:utf-8 -*-

themesType = {"0":"精品文章1","1":"精品文章2"}
urls = {"list_url":"http://115.159.116.153:8000/list", "article_url":"http://115.159.116.153:8000/article", "index_url":"http://115.159.116.153:8000"}
MainArticlesNumber = 3
PptArticlesNumber = 1
mainThemes=["0","1"]
pptThemes=["2","3","4"]
pageSize = 7
pageLimit = 9
times = 216
WebTitle = "About Love"


